create database bank;
show databases;
use bank;
create table signup(formno varchar(20),First_Name varchar(20),father_name varchar(20),Gender varchar(20),Email varchar(20),Martial_Status varchar(20),Address varchar(20),City varchar(20),State varchar(20),Pincode varchar(20));
desc signup;
use bank;
create table signuptwo(Form_NO varchar(20),Religion varchar(20),Category varchar(20),Income varchar(20),Education varchar(20),Occupation varchar(20),Senior_Citizen varchar(20),Existing_Acc varchar(20),PAN_No varchar(20),Adhar_No varchar(20));
use bank;
select * from signup;
use bank;
create table signupthree(Form_No varchar(20),Account_Type varchar(40),Card_No varchar(20),Pin_NO varchar(20),Facility varchar(20));
create table login(Form_no varchar(20),Card_No varchar(20));
use bank;
select * from login;
drop table login;
create table login(Form_no varchar(20),Card_No varchar(20),Pin varchar(20));
select * from signupthree;
select * from login;
select * from signuptwo;
use bank;
select * from login;
desc deposit;
use bank;
show tables;
show tables;
desc deposit;
select * from login;
select * from signup;
use bank;
select * from login;
drop table deposit;
use bank;
create table deposit(Pin varchar(20),date varchar(60),type varchar(20),Amount varchar(20));
select * from signupthree;
show tables;
select * from signup;
select * from signuptwo;
select * from signupthree;
select * from login;
use bank;
use bank;
select * from deposit;
select * from login;































